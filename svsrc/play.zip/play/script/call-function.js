// khai bao params


// goi ham