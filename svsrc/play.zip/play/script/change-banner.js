jQuery(document).ready(function() {

	var numWow= Math.floor((Math.random()*9));
	
	jQuery("ul.WoW ").find("li").removeClass("Active");
	jQuery("ul.WoW li").eq(numWow).addClass("Active");
	
	
	var linkIMG=jQuery("ul.WoW li").eq(numWow).find("a").attr("rel");	
	
	jQuery(".ShowNhanVat").find("img").remove();			
	$('<img />', { 'src': linkIMG, 'id': 'show-img' }).appendTo(".ShowNhanVat");		
			
	if(jQuery("ul.WoW").length>0){
		
		jQuery("ul.WoW li a").bind("mouseover",function(){		
			
			jQuery("ul.WoW ").find("li").removeClass("Active");
			jQuery(this).parent().addClass("Active");
			var linkIMG=jQuery(this).attr("rel");
			
			jQuery("#show-img").css('opacity',0);			
			//jQuery("#show-img").attr('src',linkIMG);			
			jQuery("#show-img").stop().animate({opacity:1});		
			
			jQuery(".ShowNhanVat").find("img").remove();
			
			$('<img />', { 'src': linkIMG, 'id': 'show-img' }).appendTo(".ShowNhanVat");
			
			return false;
		});
		
	}
});