jQuery(document).ready(function(){	
	if (jQuery(".SelectUI").length > 0) {      
        jQuery(".SelectUI").addSelectUI({
            scrollbarWidth: 10 //default is 10
        });
    } 	
		
	/*even header*/
	if(jQuery("#listTop1").length > 0){
		jQuery("#listTop1").jcarousel({
			scroll: 1,
			//auto: 2,
			//wrap: 'last',
			initCallback: banner_onload_callback,
			onButtonAfterAnimationCallBack: animation_callback
		});
	}
	if(jQuery("#listTop2").length > 0){
		jQuery("#listTop2").jcarousel({
			scroll: 1,
			//auto: 2,
			//wrap: 'last',
			initCallback: banner_onload_callback,
			onButtonAfterAnimationCallBack: animation_callback
		});
	}
	if(jQuery("#listTop3").length > 0){
		jQuery("#listTop3").jcarousel({
			scroll: 1,
			//auto: 2,
			//wrap: 'last',
			initCallback: banner_onload_callback,
			onButtonAfterAnimationCallBack: animation_callback
		});
	}
	if(jQuery("#listTop4").length > 0){
		jQuery("#listTop4").jcarousel({
			scroll: 1,
			//auto: 2,
			//wrap: 'last',
			initCallback: banner_onload_callback,
			onButtonAfterAnimationCallBack: animation_callback
		});
	}  		
	/*even*/
	var contentHeight, Pos ;
	jQuery("ul.ListBanner > li > a").click(function(){
		jQuery(".Content").find(".DetailEvent").hide();		
		Pos = jQuery(this).attr("rel");		
		contentHeight = jQuery(Pos).outerHeight(true);		
		jQuery(Pos).show();		
		if( (jQuery(Pos).hasClass("Scroll"))== false ) {
			jQuery(Pos).css('height',0);
			
			jQuery(".DetailEvent").removeClass("Scroll");				
			jQuery(Pos).animate({
					height:contentHeight
					}, 1000,function() {
					jQuery(Pos).addClass("Scroll");					
					}
			);
		}
		else{			
			jQuery(Pos).animate({
				height:0
				}, 1000,function(){						
				jQuery(".DetailEvent").removeClass("Scroll");
				jQuery(Pos).hide();
				jQuery(Pos).css('height', contentHeight);
			})		
		}		
		return false;
	});	
	jQuery(".jcarousel-next-horizontal").bind("click",function(){
		if( (jQuery(Pos).hasClass("Scroll"))== false ) {
		jQuery(Pos).css('height',0);		
		jQuery(".DetailEvent").removeClass("Scroll");				
		jQuery(Pos).animate({
				height:contentHeight
				}, 1000,function() {
				jQuery(Pos).addClass("Scroll");					
				}
			);
		}
		else{			
			jQuery(Pos).animate({
				height:0
				}, 1000,function(){						
				jQuery(".DetailEvent").removeClass("Scroll");
				jQuery(Pos).hide();
				jQuery(Pos).css('height', contentHeight);
			})		
		}				
	});
	jQuery(".jcarousel-prev-horizontal").bind("click",function(){
				if( (jQuery(Pos).hasClass("Scroll"))== false ) {
		jQuery(Pos).css('height',0);
		autoResize('iframe1');
		jQuery(".DetailEvent").removeClass("Scroll");				
		jQuery(Pos).animate({
				height:contentHeight
				}, 1000,function() {
				jQuery(Pos).addClass("Scroll");					
				}
			);
		}
		else{			
			jQuery(Pos).animate({
				height:0
				}, 1000,function(){						
				jQuery(".DetailEvent").removeClass("Scroll");
				jQuery(Pos).hide();
				jQuery(Pos).css('height', contentHeight);
			})		
		}	
	});
	/**********/
	if(jQuery("#container #boxTab").length >0 ){
		var actTab =0;		
		jQuery("#container #boxTab").tabs({
			event: 'mouseover',
			selected: actTab
			
		});
	}
	
	/******popup*****/
	if(jQuery("a.OpenPopup").length >0 ){	
		jQuery("a.OpenPopup").click(function(){											 
			var url = $(this).attr('href');
			var strclass = $(this).attr('rel');			
			if(jQuery('#subspamlink iframe').length>0){
				jQuery('#subspamlink iframe').attr('src',url);
				jQuery('#subspamlink').removeClass('PopupQuick');								
				jQuery('#subspamlink').addClass(strclass);
			}
			createOverlays("subspamlink");			
			jQuery('.SurveyClose').bind('click', function() {
				closeVideo('subspamlink');				
				return false;
			});
			jQuery('#thewindowbackground').bind('click', function() {
				closeVideo('subspamlink');				
				return false;
			});	
			
			return false;
		});			
	}
	
	/**************/
	var windowWidth = jQuery(window).width();
	var windowHeight = jQuery(window).height();
	var popupWidth = jQuery('.Popup').width();
	var popupHeight = jQuery('.Popup').height();
	$('.Popup').css('top',(windowHeight-popupHeight)/2);
	$('.Popup').css('left',(windowWidth-popupWidth)/2);
	
	$(window).resize(function() {
		windowWidth = jQuery(window).width();
		windowHeight = jQuery(window).height();
  		$('.Popup').css('top',(windowHeight-popupHeight)/2);
		$('.Popup').css('left',(windowWidth-popupWidth)/2);
		$('.Popup').css('opacity',1);
	});
	
	$('#viewDetail').click(
		function(){
			$('.opaEff').addClass('visible');
			$('.Popup').show();
			$('#scrollbar1').tinyscrollbar({ size: 440 });
			$('.Popup').css('opacity',1);
		}
	);
	$('.PopupClose').click(
		function(){
			$('.opaEff').removeClass('visible');
			$('.Popup').hide('visible');	
		}
	)
	$('.opaEff').click(
		function(){
			$('.opaEff').removeClass('visible');
			$('.Popup').hide('visible');	
		}
	)	
	
	/*******spitely******/
	/*$('#vukhi').pan({
		fps: 30, 
		speed: 2,
		dir: 'left' 
	});*/
});

