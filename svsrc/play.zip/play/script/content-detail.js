$.fn.custVscroll = function(options){
        var defaults = {
            clsScrollBar: 'scroller',
            clsContent: 'innerScroller',
            scrollDuration: 200,
            effect: 'linear',
            wheelAmount:10,
            keepCurrent: false,
            initTo: 'top'
        },
        internal = $.extend(defaults, options);
			
        this.each(function(e){
            var jelement = $(this),
            jcontent = jelement.find('.' + internal.clsContent),
            initScroll = 0;
			
            if(internal.keepCurrent){
                initScroll = parseInt(jcontent.css('margin-top'));
            }
			
            jelement.find('.' + internal.clsScrollBar).remove();
				
            var containerHeight = jelement.height(),
            contentHeight = jcontent.height();
			
            if(contentHeight > containerHeight){
                var jscrollbar = $('<div class="' + internal.clsScrollBar + '"><a href="javascript:;" title=""></a></div>').prependTo(jelement),
                jbar = jscrollbar.find('a'),
                scale = containerHeight / contentHeight;	
                jscrollbar.css('height', containerHeight);
				
                var draggerContHeight = jscrollbar.height(),
                draggerHeight = jbar.height(),
                scrollScale = (contentHeight - containerHeight) / (draggerContHeight - draggerHeight);
				
                jbar.draggable({ 
                    axis: 'y',
                    scroll: false,
                    addClasses: false,
                    containment: 'parent',
                    drag: function(event, ui){
                        jcontent.stop(true).animate({
                            'margin-top': -jbar.position().top * scrollScale
                        }, internal.scrollDuration, internal.effect);
                    }
                });

                jscrollbar.unbind('click.zvscroll').bind('click.zvscroll', function(e){
                    var mouseCoord = e.pageY - $(this).offset().top;
						
                    jbar.css('top', mouseCoord + draggerHeight < draggerContHeight ? mouseCoord : draggerContHeight - draggerHeight);
                    jcontent.stop(true).animate({
                        'margin-top': -jbar.position().top * scrollScale
                    }, internal.scrollDuration, internal.effect);
                });

                jelement.unbind('mousewheel.zvscroll').bind('mousewheel.zvscroll', function(event, updown){
                    var newTop = jbar.position().top - (updown * internal.wheelAmount);
					
                    if(newTop < 0){
                        newTop = 0;
                    }else if(newTop > draggerContHeight - draggerHeight){
                        newTop = draggerContHeight - draggerHeight;
                    }	
                    jbar.css('top', newTop);
                    jcontent.stop(true).animate({
                        'margin-top': -jbar.position().top * scrollScale
                    }, internal.scrollDuration, internal.effect);
					
                    return false;
                });
				
                if(initScroll){
                    jbar.css('top', Math.min(Math.abs(contentHeight - containerHeight), Math.abs(initScroll)) / scrollScale);
                    jcontent.stop(true).animate({
                        'margin-top': -jbar.position().top * scrollScale
                    }, internal.scrollDuration, internal.effect);
                }else if(internal.initTo == 'bottom'){
                    jbar.css('top', draggerContHeight - draggerHeight);
                    jcontent.stop(true).animate({
                        'margin-top': -jbar.position().top * scrollScale
                    }, internal.scrollDuration, internal.effect);
                }
            }else{
                if(parseInt(jcontent.css('margin-top')) != 0){
                    jcontent.stop(true).animate({
                        'margin-top': 0
                    }, internal.scrollDuration, internal.effect);
                }
            }
        });
    };
$.fn.showLayer = function(options){
	var defaults = {
		opacity : 0.5,
		popupClass : '.Popup',
		closeClass : '.PopupClose'
	}
	options = $.extend(defaults,options);
	var popup = $(options.popupClass);
		popup.css('opacity',0);
	return this.each(function(){
		var that = $(this);
		
		that.unbind('click').bind('click',function(e){
			if(!$('#overlay').length)
				$('<div id="overlay"></div>').appendTo(document.body);
				
			var overlay = $('#overlay');
			overlay.css({'height': $(document).height()});//fix height in ie6
			overlay.animate({'opacity':options.opacity},300).css('display','block');
			
			popup.css({
					'display':'block',
					'top': ($(window).height() - popup.height()) / 2 +  $(window).scrollTop(),
					'left': ($(window).width() - popup.width()) / 2					
			}).animate({'opacity':1},300);
			
			$(window).resize(function(){
				popup.css({
					'top': ($(window).height() - popup.height()) / 2 +  $(window).scrollTop(),
					'left': ($(window).width() - popup.width()) / 2					
				})
			});
			
			$(options.closeClass).unbind('click').bind('click',function(){
				popup.animate({'opacity':0}).css({'display':'none'});
				overlay.animate({'opacity':0},200).css('display','none');
			});
			
			$('.custom-scroll-block').custVscroll({
				clsScrollBar: 'scroller-wrapper',
			   clsContent: 'cont'
			});
			
			$('#link-function').unbind('click').bind('click',function(e){
				e.stopPropagation();
				if($('#list-function').hasClass('active')){
					$('#list-function').removeClass('active');
				}
				else{
					$('#list-function').css({
							'left':$(this).offset().left - ( $('#list-function').outerWidth() - $(this).outerWidth()),
							'top':$(this).offset().top + 30
					})
					$('#list-function').addClass('active')
				}
				
			});
				
			$(document).unbind('click').bind('click',function(){
					
					$('#list-function').removeClass('active');
			});
		});
	});
}
$(window).load(function(){	
	$('#btn-view-detail').showLayer({opacity:0.7 , popupClass:'.Popup'});
	
});