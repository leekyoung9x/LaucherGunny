/**

 */

(function(window) {
	var KEY_TIMEOUT =400,
	BLUR_TIMEOUT = 200,
	KEY_DETECT = [],
	//STATIC_URL = '/testreg/',
	STATIC_URL = 'https://img.zing.vn/idzing/theme/default/',//TODO: nho doi lai cho nay
	productId,
	callbackLogin,
	callbackRegister,
	isLogin = true,
	apiKey,
	titleButtonLogin = 'Đăng nhập',
	captcha = true,
	captchaLoginReturn,
	checking, validatedUname,
	//validUname,
	validUname = true,
	validPw,
	matchedPw,
	formLocked,
	formLoginLocked,
	regUnameKeyTimeout,
	regPwKeyTimeout,
	regConfirmPwKeyTimeout,
	data, //data response autocomplete
	document = window.document;

	// Defines error messages
	var MSG_USERNAME_OK = 'Tài khoản hợp lệ',
	MSG_USERNAME_EXISTED = 'Tên tài khoản đã tồn tại',
	MSG_USERNAME_WRONG_LENGTH = 'Tên tài khoản phải từ 6-24 ký tự',
	MSG_USERNAME_INVALID = 'Tên tài khoản trong khoảng a-z, 0-9.',
	MSG_USERNAME_NONE_CHAR = 'Tên tài khoản phải có ít nhất 1 ký tự',
	MSG_PASSWORD_OK = 'Mật khẩu hợp lệ',
	MSG_PASSWORD_INVALID = 'Mật khẩu không hợp lệ',
	MSG_PASSWORD_INVALID_UNICODE = 'Mật khẩu không dùng tiếng việt có dấu';
	MSG_PASSWORD_WRONG_LENGTH = 'Mật khẩu phải từ 6-32 ký tự',
	MSG_CONFIRMPW_OK = 'Xác nhận mật khẩu thành công',
	MSG_CONFIRMPW_INVALID = 'Mật khẩu xác nhận không đúng';
	var MSG_DEFAULT_ERROR = 'Vui lòng nhập lại thông tin trong ô này.';
	var actionForm = 0;
	// Lấy thông tin các tham số cần thiết
	var script = $('#zpp-jssdk')[0];
	if (script && script.nodeName.toLowerCase() == 'script') {
		var p = /\.js#(.*)$/.exec(script.src);
		if (p && p[1]) {
			var arr = p[1].split('&'), params = {};
			for (var i = 0, p; p = arr[i]; i++) {
				var s = p.split('=');
				params[s[0]] = s[1];
			}
			captcha = !!parseInt(params.captcha);
			productId = params.productid;
			callbackRegister = params.callbackRegister;
			callbackLogin = params.callbackLogin;
			isLogin = !!parseInt(params.isLogin);
			apiKey =params.apiKey;
			if(typeof params.titleButtonLogin !="undefined"){
				titleButtonLogin =  decodeURIComponent(params.titleButtonLogin);
			}
			
		}
	}
	
	//add css file
	$('<link href="' + STATIC_URL + '/css/register.0.5.css" type="text/css" rel="stylesheet" />').appendTo('head');
	$('<link href="' + STATIC_URL + '/css/jquery-ui.0.1.css" type="text/css" rel="stylesheet" />').appendTo('head');
		
	//add javascript file
	$('<script type="text/javascript" src="' + STATIC_URL + 'js/jquery-migrate-1.1.1.js"></script>').appendTo('head');
	
	for (var i = 48; i < 57; i++)
		KEY_DETECT.push(i);
	for (var i = 65; i < 90; i++)
		KEY_DETECT.push(i);
	for (var i = 96; i < 105; i++)
		KEY_DETECT.push(i);
	KEY_DETECT.push(190);
	KEY_DETECT.push(8);

	// Add handler for cross-domain submit
	function handleResponse() {
		if (typeof zmXCall == 'undefined')
			$.getScript("https://img.zing.vn/idzing/theme/default/js/zm.xcall-1.18.min.js", addResponseHandler);
		else
			addResponseHandler();
	}
	
	var warningIEVersionContent = '<div>\
                <p class="NoticeFail"> Bạn đang dùng phiên bản IE quá cũ. Vui lòng nâng cấp! </p>\
                <p class="DangNhapIE6"><a href="https://id.zing.vn/login/index.'+productId +'.html" title="Đăng nhập" target="_blank">Đăng nhập</a></p>\
                <p class="DangNhapIE6"><a href="https://id.zing.vn/register/index.'+productId +'.html" title="Đăng kí" target="_blank">Đăng kí</a></p><div>';
	
	function isIeLessThan7(){
		if(jQuery.browser) {
			if (jQuery.browser.msie && parseInt(jQuery.browser.version) < 7) 
			{
				// showtemplate thong bao o day 
				$("#tabQuickReg").html(warningIEVersionContent);
				$("#tabLogin").html(warningIEVersionContent);
				return true;
			}
		}
		return false;
	}
	
	function addResponseHandler() {
		zmXCall.register('ZRegisterCallback', function(data) {
			lockFormRegister(false);
			if (data.error_code == 0) {
				$('#zpp_regform .captcha').attr('class', 'captcha');
				var result;
				if (callbackRegister) {
					try {
						result = eval(callbackRegister + '();');
					} catch(ex) {}
				}
				result !== false && hideRegisterPopup();
			//result !== false && $('#feedback').html(successRegisterContent);
			} else
				showErrors(data.error_code);
		});
		
		//login here callback resp
		zmXCall.register('ZLoginCallback', function(data) {
			lockFormLogin(false);
			if (data.error_code == 0) {
				timeLoginWrong = 0;
				$('#zpp_regform .captcha').attr('class', 'captcha');
				var result;
				if (callbackLogin) {
					try {
						result = eval(callbackLogin + '({ u: "'+ data.data.u +'" , sid: "'+ data.data.sid +'" });');
					} catch(ex) {}
				}
				result !== false && hideRegisterPopup();
				
			} else{
				showErrorsLogin(data);
			}
		});
	}
	
	// Show error login after submit
	function showErrorsLogin(data) {
		var MSR_ERROR_USERNAME_PASSWORD ='Tên đăng nhập hoặc mật khẩu không đúng.';
		var MSR_ERROR_CAPTCHA_NOMATCH ='Mã xác nhận không đúng.';
		var MSR_ERROR_MANY_LOGIN ='Bạn đã đăng nhập quá số lần quy định.';
		var MSR_ERROR_USER_BANED ='Tài khoản đã bị khóa. Liên hệ hotline 1900.561.558';
		
		err= data.error_code;
		if (!err)
			return;
		
		//show div messages
		$('#tabLogin .passwordLog').addClass('OnInVaLid');
		$('#msgLoginWrongId').show();
		
		
		if (err == "2001") {//wrong username or password
			$('#noticeLoginId').text(MSR_ERROR_USERNAME_PASSWORD);
			if($('#captcha_login_id').length > 0){//if this element is not exist
				getCaptchaLogin();
			}
			$('#passwordID').val("");
		}else if (err == "2005"){//login too much
			//show capcha
			captchaLoginReturn = data.data.captchaUrl;
			$('.captcha_login').show();
			
			if($('#captcha_login_id').length <=0){//if this element is not exist
				$('#captcha_login_img_id').prepend('<input type="text" placeholder="Mã xác nhận" title="Mã xác nhận" name="imgcode" id="captcha_login_id" class="Captcha TextInputReplace">');
			}
			$('#ppcaptcha_img_login').attr('src', captchaLoginReturn);
			
			if($('#tokenLoginId').length <=0){//if this element is not exist
				$('#frmLoginPopup fieldset').append('<input type="hidden" id="tokenLoginId" name="token" value="">');
			}
			$('#tokenLoginId').val(data.data.token);
			
			$('#noticeLoginId').text(MSR_ERROR_MANY_LOGIN);
		}else if(err == "2002"){//captcha not match
			captchaLoginReturn = data.data.captchaUrl;
			$('.captcha_login').show();
			$('#loginCapNoticeId').show();
			$('#loginCapNoticeId').addClass('OnInVaLid');
			$('#ppcaptcha_img_login').attr('src', captchaLoginReturn);
			$('#tokenLoginId').val(data.data.token);
			$('#noticeLoginId').text(MSR_ERROR_CAPTCHA_NOMATCH);
		}else if(err == "2006"){//account baned
			$('#noticeLoginId').text(MSR_ERROR_USER_BANED);
			$('#passwordID').val("");
		}
	}

	// Show errors after submit
	function showErrors(err) {
		if (!err)
			return;
		var errs = err.split(',');
		if ($.inArray(-1, errs) >= 0) {
			$('#zpp_regform .formfield').hide();
			$('#zpp_regform .respmessage').show().find('.NoticeFail').html('Có lỗi xảy ra, vui lòng thử lại sau.');
		} else {
			$('#zpp_regform .captcha').attr('class', 'captcha');
			for (var i = 0; i < errs.length; i++) {
				if (errs[i] == 45) {
					showUsernameErr(MSG_USERNAME_EXISTED);
					validUname = false;
				} else if (errs[i] == 41) {
					showPwMsg(MSG_PASSWORD_INVALID, false);
					validPw = false;
				} else if (errs[i] == 42) {
					showConfirmedPwMsg(MSG_CONFIRMPW_INVALID, false);
					matchedPw = false;
				}else if (errs[i] == 43)
					$('#zpp_regform .captcha').attr('class', 'captcha OnInVaLid');
			}
		}
		getCaptcha();
	}

	//add for case IE 6
	function addxCallId(){
		xcallId = zmXCall.getXCallID();
		if(typeof xcallId == 'undefined'){
			return;
		}
		$("#reg_zmxcid").val(xcallId);
		$("#login_zmxcid").val(xcallId);
	}
	
	function showAllPopUp(options){
		if ($('#zpp_regform').size() < 1) {
			$(document.body).append('<div id="zpp_regform" class="BlockRegisterWrapper modal" style="display: none"><div class="BlockRegister' + (captcha ? ' FormCaptcha' : '') + '" style="top: 6px; left: 402px;">\
			<a title="Đóng" href="#" id="ppreg_close" class="Close">Đóng</a>\
			<ul  id="tabIdLogin" class="TabPageLogin">\
				<li class="Active"><a id="regTabId" href="#" title="Đăng ký" rel="tabQuickReg"><span>Đăng ký</span></a></li>\
		'+ (isLogin ? '<li><a href="#" title="Đã có tài khoản Zing" rel="tabLogin"><span>Đã có tài khoản Zing</span></a></li>' : '')  +
				'</ul>\
			<div id="tabQuickReg" class="TabContent">\
				<form id="feedback" method="post" target="ppreg" enctype="application/x-www-form-urlencoded" action="https://id.zing.vn/quickregister/game/jsonreg.' + productId + '.0.0.0.withoutcaptcha.html">\
					<fieldset>\
						<legend>Đăng ký nhanh Zing ID</legend>\
						<div class="formfield">\
							<div class="username" id="divuname">\
								<input type="text" maxlength="24" placeholder="Tên tài khoản Zing" title="Tên tài khoản" class="TextInputReplace" name="sUserName" id="ppreg_name">\
								<p class="Notice"></p>\
							</div>\
							<div id="suggess" style="position: absolute;"></div>\
							<span id="loadingAutocomplete"><img src="https://img.zing.vn/idzing/theme/default//images/quickreg/icon-loading.gif" id="loadingimg"/></span>\
							<div class="password" id="divpassword">\
								<input type="password" placeholder="Mật khẩu" title="Mật khẩu" class="TextInputReplace" name="sPassWord1" id="ppreg_pw">\
								<p class="Notice"></p>\
							</div>\
							<div class="confirmpw" id="divconfirmpassword">\
								<input type="password" placeholder="Xác nhận mật khẩu" title="Xác nhận mật khẩu" class="TextInputReplace" name="sConfirm_PassWord1" id="ppreg_confirmpw">\
								<p class="Notice"></p>\
							</div>\
							<div class="captcha" ' + (captcha ? '' : ' style="display:none"') + '>\
								<input class="Captcha TextInputReplace" id="ppreg_captcha" name="sVerifyCode" type="text" title="Mã xác nhận" placeholder="Mã xác nhận">\
								<p class="ImgCaptcha"><img id="ppcaptcha_img" src="" width="180" height="33" alt="" style="display: none"><a href="#" id="ppreg_f5captcha" title="Tạo mã xác nhận khác"><img src="' + STATIC_URL + '/images/quickreg/refresh.png" alt="" /></a></p>\
								<p class="Notice">Vui lòng nhập lại thông tin trong ô này.</p>\
							</div>\
							<div class="agreepolicy">\
								<input type="submit" value="Đăng ký" class="submit" id="ppreg_submit">\
								<p class="Agree">\
									<input type="checkbox" class="InputAgree" name="dongy" id="pp_agreepolicy" checked="checked">\
									&nbsp;<span>\
									<label style="display: inline" for="pp_agreepolicy">Đồng ý với </label>\
									<a href="https://id.zing.vn/general/policy.38.html" target="_blank" class="ThoaThuan"><strong>thỏa thuận sử dụng</strong></a></span> </p>\
								<p class="Notice">Bạn chưa đồng ý với thỏa thuận sử dụng</p>\
							</div>\
						</div>\
						<div style="display: none" class="respmessage">\
							<p class="NoticeFail"></p>\
							<input type="button" value="Đăng ký lại" id="ppreg_return" class="submit">\
						</div>\
					</fieldset>\
					<input type="hidden" value="be60750263326192761de9ff51f2d5eb_1366093117.7617" name="sTokenCode" id="ppreg_captoken">\
					<input type="hidden" value="" name="zmxcid" id="reg_zmxcid">\
				</form>\
			</div>\
			'+ (isLogin ? '<div id="tabLogin" class="TabContent">\
				<form target="pplogin" action="https://sso3.zing.vn/plogin" id="frmLoginPopup" method="post">\
					<fieldset>\
						<legend>Ðăng nhập</legend>\
						<div class="usernameLog">\
							<input type="text" name="u" id="usernameID" placeholder="Tên tài khoản Zing" class="">\
						</div>\
						<div class="passwordLog OnInVaLid">\
							<input type="password" name="p" id="passwordID" placeholder="Mật khẩu" class="">\
						</div>\
						<div class="captcha_login" id="captcha_login_img_id" style="display: none " >\
								<p class="ImgCaptcha"><img width="180" height="33" style="display: inline;" alt="" src="" id="ppcaptcha_img_login"><a title="Tạo mã xác nhận khác" id="login_f5captcha" href="#"><img id="img_login_captcha" alt="" src="'+ STATIC_URL+'images/quickreg/refresh.png"></a></p>\
						</div>\
						<div class="passwordLog OnInVaLid" style="height: 30px;" id="msgLoginWrongId">\
							<p class="Notice" id="noticeLoginId">Tên tài khoản Zing hoặc mật khẩu không đúng.</p>\
						</div>\
						<div class="BtPlayNow">\
							<input type="submit" title="'+titleButtonLogin+'" class="submit" value="'+titleButtonLogin+'">\
						</div>\
						<ul class="Disc">\
							<li><a href="https://id.zing.vn/forgotinfo/index.' + productId +'.html" title="Quên mật khẩu" target="_blank">Quên mật khẩu ?</a></li>\
							<li>Nếu chưa có ZingID, bạn có thể <a href="#" rel="tabQuickReg" class="ChangeTab">đăng ký tại đây.</a></li>\
							\
						</ul>\
						<input type="hidden" id="productidId" name="pid" value="'+ productId +'">\
						<input type="hidden" id="apiKeyId" name="apikey" value="'+ apiKey +'">\
						<input type="hidden" value="" name="zmxcid" id="login_zmxcid">\
				</fieldset>\
				</form>\
			</div>' : '')+
				'<iframe style="border: 0; width: 0; height: 0" name="ppreg"></iframe>\
			  <iframe style="border: 0; width: 0; height: 0" name="pplogin"></iframe>\
			</div>\
			</div>');
			handleRegisterForm();
			handleResponse();
			handleChangeTab();
			handleLoginForm();
			
			setTimeout(addxCallId, 1000);
		} else {
			$('#ppreg_log').remove();
			returnRegisterForm(false);
		}
		$('#zpp_regform').append('<iframe id="ppreg_log" src="https://id.zing.vn/quickregister/game/jsonreg.' + productId + '.0.0.0.withoutcaptcha.html' + (options && options.popup ? '' : '?reg_embed=true') + '" style="border: 0; width: 0; height: 0"></iframe>');
		getCaptcha(function() {
			$('#zpp_regform').show();
			$('#ppreg_name').focus();
			setPopupPosition(options);
		});
	}
	
	// Handle popup
	function handleRegisterForm() {
		$('#ppreg_name').attr('autocomplete','off');
		//check field username
		//autocomplete here
		var isSelectFromAutoComplete = false;
		$('#loadingAutocomplete').hide();
		field = $('#zpp_regform .username');
		
		//autocomplete event.
		$( '#ppreg_name' ).autocomplete({
			  source: function( request, response ) {
				  $.getJSON('https://id.zing.vn/v2/uname-suggestion?username=' + $('#ppreg_name').val() + '&cb=?', function(resp) {
					  isSelectFromAutoComplete = false;
					  $('#loadingAutocomplete').show();
					  switch(parseInt(resp.err)) {
						  case 1:
							  validUname = true;
							  $('#loadingAutocomplete').hide();
							  if($('#ppreg_name').val().length < 6){
							      validUname = false;
							  }
							  checking = false;
							  validatedUname = resp.data;
							  
							  if(validateUnamClient(validatedUname, field) == false){
							     validUname = false;
							      $( '#ppreg_name' ).autocomplete('close');
							      break;
							  }
							 isSelectFromAutoComplete = true;
							  $( '#ppreg_name' ).autocomplete('close');
							  $('#zpp_regform .username').attr('class', 'username OnVaLid').children('.Notice').html(MSG_USERNAME_OK);
							  
							  break;
						  case 0: //hien auto complete 
							  $('#loadingAutocomplete').hide(); 
							  checking = false;
							  
							  valueUname = $('#ppreg_name').val();
							  if(validateUnamClient(valueUname , field) == false){
							      validUname = false;
							      $('#loadingAutocomplete').hide(); 
							      $( '#ppreg_name' ).autocomplete('close');
							      break;
							  }
							  
							  showUsernameErr(MSG_USERNAME_EXISTED);
							  var data = $.parseJSON(resp.data); //parseJson to string
							  response( $.map( data, function( item ) {
							    return {
							      label: item,
							      value: item
							    }
							  }));
							  break;
								  
						  default:
							  //$('#zpp_regform .username').attr('class', 'username');
							  $('#loadingAutocomplete').hide();
							  validatedUname = $('#ppreg_name').val();
							  if(validateUnamClient(validatedUname, field) == false){
							      validUname = false;
							      $( '#ppreg_name' ).autocomplete('close');
							      break;
							  }else{
                                                              validUname = false;
                                                          }
							  checking = false;
							  showUsernameErr(MSG_USERNAME_EXISTED);
							  break;
					  }
				  })
			  },
			  //minLength: 2,
			  select: function( event, ui ){
				  $('#loadingAutocomplete').hide();
				  validUname = true;
				  checking = false;
				  isSelectFromAutoComplete = true;
				  validatedUname = ui.item.value;
				  
				  if(validateUnamClient(validatedUname) == false){
				      return;
				  }
				  
				  $('#zpp_regform .username').attr('class', 'username OnVaLid').children('.Notice').html(MSG_USERNAME_OK);
			    
			  },
			  close: function( event, ui ) {
				$('#loadingAutocomplete').hide();
				checking = false;
				var nowValue = $('#ppreg_name').val();
				if(validateUnamClient(nowValue) == false){
				      return;
				}
				
				if(isSelectFromAutoComplete != true)
				{
				    validUname = false;
				    showUsernameErr(MSG_USERNAME_EXISTED);
				    isSelectFromAutoComplete = false;
				}
			      //  $('#zpp_regform .username').attr('class', 'username OnInVaLid').children('.Notice').html(MSG_DEFAULT_ERROR);			
			  }
	      });
		//}
      
	      
	      $('#ppreg_name').keyup(function(e) {
			if (!this.value)
				return;
			if (e.keyCode == 13) {
				regUnameKeyTimeout && clearTimeout(regUnameKeyTimeout);
				register();
			} else if ($.inArray(e.keyCode, KEY_DETECT) >= 0)
				regUnameKeyTimeout = setTimeout(checkUsername, KEY_TIMEOUT);
		}).blur(checkUsername);
		$('#ppreg_pw').keyup(function(e) {
			if (!this.value)
				return;
			if (e.keyCode == 13) {
				regPwKeyTimeout && clearTimeout(regPwKeyTimeout);
				register();
			} else
				regPwKeyTimeout = setTimeout(checkPassword, KEY_TIMEOUT);
		}).blur(checkPassword);
		
		$('#ppreg_confirmpw').keydown(function(e) {
			if (e.keyCode == 9)
			{
			    validPw = true;
			    return;
			}
		});
		
		$('#ppreg_confirmpw').keyup(function(e) {
			if (!this.value)
				return;
			regConfirmPwKeyTimeout && clearTimeout(regConfirmPwKeyTimeout);
			if (e.keyCode == 13)
				register();
			else
				regConfirmPwKeyTimeout = setTimeout(checkConfirmedPassword, KEY_TIMEOUT);
		}).blur(checkConfirmedPassword);
		
		
		$('#ppreg_captcha');
		$('#ppreg_f5captcha').click(getCaptcha);
		$('#ppreg_submit').click(register);
		$('#ppreg_close').click(hideRegisterPopup);
		$('#zpp_regform form').bind('reset', hideAllMessages);
		$('#ppreg_return').click(returnRegisterForm);
		$(window).resize(setPopupPosition);
		$.getScript(STATIC_URL + '/js/placeholder-2.0.1.js');
	}

	function getTimeout(e) {
		return e && e.type == 'blur' ? BLUR_TIMEOUT : KEY_TIMEOUT;
	}

	function setPopupPosition(options) {
		var popup = $('#zpp_regform').children(),
		left, top;
		left = Math.round( ($(window).width() - popup.outerWidth()) / 2 );
		if (options && $.isNumeric(options.offsetLeft))
			left += options.offsetLeft;
		top = Math.round( ($(window).height() - popup.outerHeight()) / 2 );
		if (options && $.isNumeric(options.offsetTop))
			left += options.offsetTop;
		popup.css({
			top: Math.max(0, top) + 'px',
			left: Math.max(0, left) + 'px'
		});
	}

	function hideRegisterPopup() {
		regConfirmPwKeyTimeout && clearTimeout(regConfirmPwKeyTimeout);
		regUnameKeyTimeout && clearTimeout(regUnameKeyTimeout);
		regPwKeyTimeout && clearTimeout(regPwKeyTimeout);
		validUname = false;
		validPw = false;
		matchedPw = false;
		$('#zpp_regform').hide().find('form')[0].reset();
		$('#ppcaptcha_img').hide();
		return false;
	}

	function returnRegisterForm(captcha) {
		$('#zpp_regform .formfield').show();
		$('#zpp_regform .respmessage').hide();
		captcha != false && getCaptcha(setPopupPosition);
	/*if(captcha != false){
		   // getCaptcha(setPopupPosition);
		   // $("#zpp_regform .BlockRegister").css("height", "507px");
		}else{
		 //   $("#zpp_regform .BlockRegister").css("height", "435px");
		}*/
			
	}

	function hideAllMessages() {
		$('#zpp_regform .username').attr('class', 'username');
		$('#zpp_regform .password').attr('class', 'password');
		$('#zpp_regform .confirmpw').attr('class', 'confirmpw');
		$('#zpp_regform .captcha').attr('class', 'captcha');
		$('#zpp_regform .agreepolicy').removeClass('OnInVaLid');
		$('#tabLogin .passwordLog').removeClass('OnInVaLid');
	}

	/**
	 * Functions for validating username, password
	 */
	function checkUsername(e) {
		if (e && e.type == 'blur' && !this.value) {
			return;
		}
		regUnameKeyTimeout && clearTimeout(regUnameKeyTimeout);
		regUnameKeyTimeout = setTimeout(validateUsername, getTimeout(e));
	}

	function validateUsername() {
		if (checking)
			return;
		
		checking = true;
		var unameinput = $('#ppreg_name');
		uname = unameinput.val();
		field = $('#zpp_regform .username');
		if (validatedUname == uname) {
			checking = false;
			//field.children('.Notice').html() != MSG_USERNAME_OK && $('#ppreg_name').focus();
			return;
		}
		if (uname.length < 6 || uname.length > 24) {
			showUsernameErr(MSG_USERNAME_WRONG_LENGTH, field);
			checking = false;
			validUname = false;
			return;
		}
		if (!/^[a-z0-9]+$/i.test(uname)) {
			showUsernameErr(MSG_USERNAME_INVALID, field);
			checking = false;
			validUname= false
			return;
		}
		if (/^[0-9]+$/.test(uname)) {
			showUsernameErr(MSG_USERNAME_NONE_CHAR, field);
			checking = false;
			validUname = false;
			return;
		}
		//field.attr('class', 'username OnWaitting').children('.Notice').html('Đang kiểm tra tài khoản');
		//field.attr('class', 'username OnWaitting').children('.Notice');
		
		
	}
	
	//var start = function(){new Suggest.Local("ppreg_name", "suggest", list);};
	function getsuggest(data){
	    return new Suggest.Local("ppreg_name", "suggest", data);
	  
	}
	
	function validateUnamClient(validatedUnameValue, field){
		if (validatedUnameValue.length < 6 || validatedUnameValue.length > 24) {
			showUsernameErr(MSG_USERNAME_WRONG_LENGTH, field);
			return false;
		}
		if (!/^[a-z0-9]+$/i.test(validatedUnameValue)) {
			showUsernameErr(MSG_USERNAME_INVALID, field);
			return false;
		}
		if (/^[0-9]+$/.test(validatedUnameValue)) {
			showUsernameErr(MSG_USERNAME_NONE_CHAR, field);
			return false;
		}
		return true;
	}

	function showUsernameErr(msg, field) {
		
		field = field || $('#zpp_regform .username');
		
		if(actionForm == 0 || $('#ppreg_name').val() != "") {
			
			field.attr('class', 'username OnInVaLid').children('.Notice').html(msg);
		} else {
			field.attr('class', 'username OnInVaLid').children('.Notice').html(MSG_DEFAULT_ERROR);
		}
	//$('#ppreg_name').focus();
	}

	function checkPassword(e) {
		if (e && e.type == 'blur' && !this.value)
		{
			
			$('#zpp_regform .password').attr('class', 'password');
			return;
		}
		regPwKeyTimeout && clearTimeout(regPwKeyTimeout);
		regPwKeyTimeout = setTimeout(validatePassword, 0);
	}

	function validatePassword() {
		var pwinput = $('#ppreg_pw'),
		pw = pwinput.val(),
		field = $('#zpp_regform .password'),
		msg;
		validPw = checkTextLength(pw,6,32);
		if (pw == pwinput.attr('placeholder')) {
			field.attr('class', 'password');
			validPw = false;
			showPwMsg(msg, validPw, field);
			return;
		}
		if (!validPw)
			msg = MSG_PASSWORD_WRONG_LENGTH;
		else if (!checkUnicode(pw)){
		  	msg = MSG_PASSWORD_INVALID_UNICODE;
			validPw = false;
		}
		else {
			msg = MSG_PASSWORD_OK;
 			if($('#ppreg_confirmpw').val() != "") {
 				matchPassword();		
 				if(!matchedPw) {
 					//$('#ppreg_confirmpw').focus();
 					return false;
 				}
 			}
		}
		showPwMsg(msg, validPw, field);
	}

	function checkTextLength(str,minlen,maxlen){
		if(str.length<minlen || str.length>maxlen){
			return false;
		}
		return true;
	}

	function checkUnicode(stringIn) {
		for (var i=0;i<=stringIn.length-1;i++) {
			if ( stringIn.charCodeAt (i) < 32 || stringIn.charCodeAt (i) > 126 )
				return false;//not unicode
		}
		return true;//is unicode
	}

	function showPwMsg(msg, valid, field) {
		field = field || $('#zpp_regform .password');
		
		if(actionForm == 0 ) {
			field.attr('class', 'password On' + (valid ? '' : 'In') + 'VaLid').children('.Notice').html(msg);
		} else {
			field.attr('class', 'password On' + (valid ? '' : 'In') + 'VaLid').children('.Notice').html(MSG_DEFAULT_ERROR);
		}
	//msg != MSG_PASSWORD_OK && $('#ppreg_pw').focus();//focus, no go other place
	}

	function checkConfirmedPassword(e) {
		if (e && e.type == 'blur' && !this.value){
			$('#zpp_regform .confirmpw').attr('class', 'confirmpw');
			return;
		}
		
		regConfirmPwKeyTimeout && clearTimeout(regConfirmPwKeyTimeout);
		regConfirmPwKeyTimeout = setTimeout(matchPassword, 0);
		
	}

	function matchPassword() {
		
		if(validPw == false) {
			matchedPw = false;
			msg = MSG_CONFIRMPW_INVALID;
			
			showConfirmedPwMsg(msg, matchedPw, field);
			return;
		}
		
		var pw = $('#ppreg_pw').val(),
		field = $('#zpp_regform .confirmpw');
		if (!pw) {
	
			field.attr('class', 'confirmpw');
			showConfirmedPwMsg(msg, matchedPw, field);
			return;
		}
		var cfpwinput = $('#ppreg_confirmpw'),
		cfpw = cfpwinput.val();
		if (pw == cfpwinput.attr('placeholder')) {
		
			field.attr('class', 'confirmpw');
			matchedPw = false;
			showConfirmedPwMsg(msg, matchedPw, field);
			return;
		}
		var msg;
	
		matchedPw = pw == cfpw;
		if (matchedPw)
			msg = MSG_CONFIRMPW_OK;
		else
			msg = MSG_CONFIRMPW_INVALID;
		showConfirmedPwMsg(msg, matchedPw, field);
	}

	function showConfirmedPwMsg(msg, matched, field) {
		field = field || $('#zpp_regform .confirmpw');
		
		if(actionForm == 0 ) {
			field.attr('class', 'confirmpw On' + (matched ? '' : 'In') + 'VaLid').children('.Notice').html(msg);
		} else {
			field.attr('class', 'confirmpw On' + (matched ? '' : 'In') + 'VaLid').children('.Notice').html(MSG_DEFAULT_ERROR);
		}
		
	}
	/**
	 * End validate functions
	 */

	function getCaptcha(callback) {
		var func = 'PPCaptchaCallback' + Math.floor(Math.random() * 10000),
		script = $('<script></script>').attr({
			type: 'text/javascript', 
			src: 'https://id.zing.vn/quickregister/game/captchatoken.' + productId + '.' + func + '.0.0.withoutcaptcha.html'
		})[0];
		window[func] = function(data) {
			if (!data || data.token == 'none') {
				captcha = false;
				$('#zpp_regform .BlockRegister').removeClass('FormCaptcha');
				$('#zpp_regform .captcha').hide();
			} else {
				captcha = true;
				$('#zpp_regform .BlockRegister').addClass('FormCaptcha');
				$('#zpp_regform .captcha').show();
				if ($('#ppreg_captoken').size() < 1)
					$('#feedback').append('<input id="ppreg_captoken" type="hidden" name="sTokenCode" value="' + data.token + '" />');
				else
					$('#ppreg_captoken').val(data.token);
				$('#ppcaptcha_img').attr('src', data.domain).show();
			}
			
			//set height of register form
			if(captcha){
				$("#zpp_regform .BlockRegister").css("height", "507px");
			}else{
				$("#zpp_regform .BlockRegister").css("height", "435px");
			}
			
			$.isFunction(callback) && callback();
			document.getElementsByTagName("HEAD")[0].removeChild(script);
			try {
				delete window[func];
			} catch(ex) {}
		};
		document.getElementsByTagName('HEAD')[0].appendChild(script);
		return false;
	}
	
	
	function getCaptchaLogin() {
		var sufix = '&rand=' + Math.floor(Math.random() * 10000);
		$("#ppcaptcha_img_login").attr("src", captchaLoginReturn + sufix);
	}
	

	// Lock/unlock form while submitting
	function lockFormRegister(lock) {
		formLocked = lock;
		$('#ppreg_name').attr('readonly', lock);
		$('#ppreg_pw').attr('readonly', lock);
		$('#ppreg_confirmpw').attr('readonly', lock);
		$('#ppreg_captcha').attr('readonly', lock);
		$('#ppreg_submit')[lock ? 'addClass' : 'removeClass']('InputOff');
	}
	
	// Lock/unlock form while submitting
	function lockFormLogin(lock) {
		formLoginLocked = lock;
		$('#usernameID').attr('readonly', lock);
		$('#passwordID').attr('readonly', lock);
		$('#captcha_login_id').attr('readonly', lock);
	//$('#ppreg_submit')[lock ? 'addClass' : 'removeClass']('InputOff');
	}
	//check format error
	function formatError(){
	    var isOnvalidUname = $('#divuname').attr("class");
		var obj = null;
	    if(isOnvalidUname.indexOf("OnInVaLid") != -1){
	      $('#divuname .Notice').html(MSG_DEFAULT_ERROR);
		  obj = $('#ppreg_name');
	    }
	    
	    var isOnvalidpwd = $('#divpassword').attr("class");
	    if(isOnvalidpwd.indexOf("OnInVaLid") != -1){
	      $('#divpassword .Notice').html(MSG_DEFAULT_ERROR);
		  if(obj == null) {
				obj = $('#ppreg_pw');
			}
	    }
	    
	     var isOnvalidconfirmpwd = $('#divconfirmpassword').attr("class");
	    if(isOnvalidconfirmpwd.indexOf("OnInVaLid") != -1){
	      $('#divconfirmpassword .Notice').html(MSG_DEFAULT_ERROR);
		  if(obj == null) {
				obj = $('#ppreg_confirmpw');
			}
	    }
		
	  
	}
	
	// Submit function
	function register() {
		//case uname ok, pw and pwconfirm not ok
		
		actionForm = 1;
		if (formLocked)
			return false;
		var err = true;
		//!validPw && validatePassword();
		//!matchedPw && matchPassword();
		err = !validPw || !matchedPw;
		if (validatedUname != $('#ppreg_name').val())
			validateUsername();
		else
			err = err || !validUname;
		
// 		if($('#ppreg_name').val() ==''){
// 			$('#ppreg_name').focus();
// 			return false;
// 		}
		
			
		if(!validUname || $('#ppreg_name').val() =='') {
			$('#ppreg_name').focus();
			formatError();
			actionForm = 0;
			return false;
		}
		
		if($('#ppreg_pw').val() == "") {
			validPw=false;
		}
		!validPw && validatePassword();
		if(!validPw || $('#ppreg_pw').val() == "") {
// 			formatError();
			$('#ppreg_pw').focus();
			formatError();
			actionForm = 0;
			return false;
		}
		!matchedPw && matchPassword();
		
		if(!matchedPw) {
			//formatError();
			$('#ppreg_confirmpw').focus();
			formatError();
			actionForm = 0;
			return false;
		}
		
		err = !validPw || !matchedPw;
		
		if (captcha) {
			var cval = $('#ppreg_captcha').val();
			if($.trim(cval).length !=6) {
				$('#zpp_regform .captcha')['addClass']('OnInVaLid');
				formatError();
				err = true;
			} else {
				$('#zpp_regform .captcha')['removeClass']('OnInVaLid');
				err = false;
			}
			
		}
		var agree = $('#pp_agreepolicy'),
		agfield = $('#zpp_regform .agreepolicy');
		if (!agree.attr('checked')) {
			agfield.addClass('OnInVaLid');
			err = true;
		} else
			agfield.removeClass('OnInVaLid');
		actionForm = 0;
		if (checking || err){
			
			
			return false;
		}
		lockFormRegister(true);
		$('#feedback').submit();
		return false;
	}

	// Add click handler for default element to show popup
	$('#ppregister_link').click(function() {
		showAllPopUp({
			popup: true
		});
		//neu version nho hon 7
		isIeLessThan7();
		return false;
	});
	
	//show tablogin
	function handleChangeTab(){
		if ( jQuery("ul#tabIdLogin li a").length > 0 ) {
			jQuery("ul#tabIdLogin li a").bind ("click", function () {
				var liTab= jQuery(this).attr("rel");		
				jQuery("ul#tabIdLogin li").removeClass("Active");
				jQuery(this).parent().addClass("Active");
				jQuery(".TabContent").hide();
				jQuery("#" +liTab).show();	
				return false;

			})
		}
		if ( jQuery("a.ChangeTab").length > 0 ) {
			jQuery("a.ChangeTab").bind ("click", function () {
				var liTab= jQuery(this).attr("rel");		
				showTabLogin(liTab);
				return false;	
			})
		}
	}
	//show tab login
	function showTabLogin(liTab){
		jQuery("ul#tabIdLogin li").removeClass("Active");
		var linkDoc= jQuery('ul#tabIdLogin li a');

		jQuery.each(linkDoc, function(i, val) { 
			if( jQuery(this).attr("rel")==liTab){
				jQuery(this).parent().addClass("Active");
			}
		})	
		jQuery(".TabContent").hide();
		jQuery("#" +liTab).show();		

	}
	function checkURLReferer(urlArray){
		var _referer = document.referrer.split('/');			
		var _url =  _referer[2];
		if(_referer[3]=='intro'){
			return false;
		}
		for (i in urlArray){
			var pattUrl = new RegExp(urlArray[i]);
			if (pattUrl.test(_url)){
				return true;
			} 
		}
		return false;
	}
	function handleLoginForm() {
		$('#login_f5captcha').click(getCaptchaLogin);
		$('#productidId').val(productId);
		$('#apiKeyId').val(apiKey);
		//$('#tabLogin .passwordLog').removeClass('OnInVaLid');
		//msgLoginWrongId
		$('#msgLoginWrongId').hide();
	}
	
	
	window.ZRegisterWidget = {
		showPopup: showAllPopUp,//showRegisterPopup,
		hidePopup: hideRegisterPopup,
		hideNotices: hideAllMessages,
		setPopupPosition: function(left, top) {
			var popup = $('#zpp_regform').children();
			$.isNumeric(left) && popup.css('left', left + 'px');
			$.isNumeric(top) && popup.css('top', top + 'px');
		}
	};
	
	
	//var start = function(){new Suggest.Local("ppreg_name", "suggest", list);};
	//window.addEventListener ?  window.addEventListener('load', start, false) : window.attachEvent('onload', start);
	
	
	
})(window);



