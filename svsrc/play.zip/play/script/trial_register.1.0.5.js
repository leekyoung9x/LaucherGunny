// JavaScript Document 30/06
var count = 0;
var old_acc = '';
var	ACCOUNT_NAME_REG_INVALID	=  'Tên đăng nhập không hợp lệ, bạn phải nhập từ 6-24 ký tự và trong khoảng a-z, 0-9 và phải có ít nhất 1 chữ cái.';
var	PASSWORD1_REG_INVALID			=  'Mật khẩu không đúng.';
var	PASS1_AND_CONFIRM_PASS1_NO_MATCH	=  'Xác nhận mật khẩu không đúng.';
var	VERIFY_TEXT_IN_IMAGES_INVALID	=  'Mã xác nhận hình ảnh không đúng.';
var	USER_DOES_NOT_CHECK_TERM		=  'Chưa nhấn vào đồng ý với thỏa thuận sử dụng.';
var	NOT_SUGGESTION	=  'Không có gợi ý cho tên đăng nhập.';

var NOTE = 'Bạn vui lòng kiểm tra các thông tin sau: \n';
var log_action = "";
function setCookie( name, value, expires, path, domain, secure )
{
	// set time, it's in milliseconds
	var today = new Date();
	today.setTime( today.getTime() );

	/*
	if the expires variable is set, make the correct
	expires time, the current script below will set
	it for x number of days, to make it for hours,
	delete * 24, for minutes, delete * 60 * 24
	*/
	if ( expires )
	{
		expires = expires * 1000 * 60 * 60 * 24;
	}
	var expires_date = new Date( today.getTime() + (expires) );

	document.cookie = name + "=" +escape( value ) +
	( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
	( ( path ) ? ";path=" + path : "" ) +
	( ( domain ) ? ";domain=" + domain : "" ) +
	( ( secure ) ? ";secure" : "" );
}
/***####################################################### */
function getError_html(error_code){
	return "<li>"+error_code+"</li>";
}
function SubmitFrm(){
	error_mess = 0;
	chk_focus = 0;
	var mess_eror = '';//NOTE;
	var frm = document.getElementById("frmRegister");
	//if(jQuery.trim(frm.sUserName.value) == '')return false;
	if(flag_valid_acc == 0 && jQuery.trim(frm.sUserName.value) != '' && jQuery.trim(frm.sUserName.value) != 'Zing ID') 
	{
	
		if(!checkAccount(frm.sUserName,6,24,true)){	
			alert(ACCOUNT_NAME_REG_INVALID);
		}else{
			show_account_valid();
		}
		
		
	}
	//check acc

	if(!checkAccount(frm.sUserName,6,24,true)){
		
		frm.sUserName.focus();
		chk_focus = 1;
		error_mess = 1;
		mess_eror += '+ '+ACCOUNT_NAME_REG_INVALID + '\n';
		flag_error = 1;
		$('#show_checkaccount').html("<img src='"+ IMG_URL  +"/theme/default/images/icon-notvalid.gif' />");
		return false;
		//mess_eror += getError_html(ACCOUNT_NAME_REG_INVALID);
	}
	if(frm.sPassWord1.value == "" || frm.sPassWord1.value == "Mật khẩu") {
		flag_error = 2;
		show_error_message(PASSWORD1_REG_INVALID);
		frm.sPassWord1.focus();
		return false;
	}
	if(!checkPassword()) {
		return false;
	}
	
	if(frm.sConfirm_PassWord1.value == "" || frm.sConfirm_PassWord1.value == "Xác nhận mật khẩu") {
		
		flag_error = 3;
		show_error_message(PASS1_AND_CONFIRM_PASS1_NO_MATCH);
		frm.sConfirm_PassWord1.focus();
		return false;
	}
	if(!checkPasswordConfirm()) {
		return false;
	}
	
	if(frm.sVerifyCode.value == "" || frm.sVerifyCode.value == "Mã xác nhận") {
		flag_error = 4;
		show_error_message(VERIFY_TEXT_IN_IMAGES_INVALID);
		frm.sVerifyCode.focus();
		return false;
	}
	if(!checkCaptcha()) {
		return false;
	}
	
	if(!frm.dongy.checked){
				
		error_mess = 1;
		show_error_message(USER_DOES_NOT_CHECK_TERM);
		log_action += "7,";
		return false;
		//mess_eror += getError_html(USER_DOES_NOT_CHECK_TERM);	
	}
	if(error_mess)	{
		//open_mess_error(1,mess_eror);
		//return false;
		//alert(mess_eror);
		return false;
	}
	setCookie('reg_client_action',log_action,0,'/','zing.vn');
	//frm.submit();
	return true;
}

var cur_acc = '';
var account_list = '';
var flag_acc_status = false;
var flag_valid_acc = 0;
var account_list = '';
var cur_acc_5 = '';
var chkAccErr = '';
function checkAcc(isSuggestion){

	var showAlert = true;
	if(isSuggestion == 2) {
		var showAlert = false;
	}
	//disable suggestion
	isSuggestion = 0;
	
	var sUserName = $('#sUserName').val();
	
	var frm = document.getElementById("frmRegister");
	if(!checkAccount(frm.sUserName,6,24,true)){	
		closeSuggest();
		
			flag_error = 1;
			$('#show_checkaccount').html("<img src='"+ IMG_URL  +"/theme/default/images/icon-notvalid.gif' />");
		
		
		if(frm.sUserName.value.length >= 6) {
			log_action += "1,";
			
		}
		frm.sUserName.focus();
		return false;
	}	
	
	
	var sessionRegisterPage = $('#sessionRegisterPage').val();
	try
	{
		/*
		$.post("/register/check.html", { 
			   'ACC': sUserName, 
			   '1ST': sUserName, 
			   '2ND': '', 
			   '3RD': '',
			   'isSuggesstion': isSuggestion,
			   'sessionRegisterPage': sessionRegisterPage
			 }, */
			 
		$.post("/checkaccount?ACC="+sUserName.toLowerCase(), { 
			  
			 },
		
		function(json){ 				
			
			cur_acc = sUserName;
			if(json['flag'] == 0){				
				flag_valid_acc = 0;
				suggestion_error2();
				flag_acc_status = false;
				return false;
			}
			if(json['flag'] == 1){
				flag_valid_acc = 1;
				show_account_valid();
				flag_acc_status = true;
				return true;
			}
			if(json['flag'] == 2){
				flag_valid_acc = 0;	
				account_list = json['account'];
				get_more_account();
				flag_acc_status = false;
				return false;
			}
			if(json['flag'] == 3){
				flag_valid_acc = 0;
				chkAccErr = 3;			
				account_list = '';
				suggestion_error2();	
				return false;
			}
			if(json['flag'] == 5){
				log_action += "11,";
				cur_acc_5 = sUserName;
				flag_valid_acc = 0;
				chkAccErr = 5;					
				suggestion_error2();	
				return false;
			}
			suggestion_error2();	
		},'json'
	);
	
	}	
	catch(err)
	{
		suggestion_error2();	
	}
	//suggestion_error2();	
}
function show_account_valid(){
	$('#show_checkaccount').html("<img src='"+ IMG_URL  +"/theme/default/images/icon-valid.png' />");
	if(flag_error == 1)
		show_error_message("");
	//var acc = $('#sUserName').val();
	//selectAcc(acc);
	//var html = "<div class='title_acc_valid'>Tên đăng nhập hợp lệ. <br/>Bạn có thể sử dụng tên đăng nhập này.</div>";
	//$('#suggest_account').show();
	//$('#sub_suggest_account').html(html);
	
}
function get_more_account(){
	$('#suggest_account').show();
	if(account_list == ''){
		suggestion_error();
		return false;
	}
	var html = get_html_suggestion1(account_list);
	$('#sub_suggest_account').html(html);
}
function get_html_suggestion(account){
	var html = '<span class="close_suggestion"> <a href="javascript:void(0)" onclick="closeSuggest();">[x]</a> </span>';
		html+= '<div class="title_acc_invalid">Tên đăng nhập đã tồn tại, gợi ý cho bạn:</div>';
	//html += '<ul>';
	var index = '';
	var tmp = new Array();
	if(account.length > 0  && account[0] != 1){
		if(account.length > 5){
			var max_ = 5;
		}else{
			var max_ = account.length;	
		}		
		for(var i=0;i<max_;i++){
			var index = i;
			html += '<a onclick="selectAcc(\''+account[index]+'\')" href="javascript:void(0)">'+account[index]+'</a><br/>';
			tmp[i] = index;
		}
	}else{
		var html = '<span class="close_suggestion"> <a href="javascript:void(0)" onclick="closeSuggest();">[x]</a> </span>';
		html+= "<div class='title_acc_invalid'>";
		if(chkAccErr == 5){
			html+= "Không có gợi ý cho tên đăng nhập.</div>";
		}else{
			html+= "Tên đăng nhập đã tồn tại.</div>";
		}
	}
	//html += '</ul>';
	return html;
}
function show_error_message(mess) {
	
	$('#show_error_msg').html("<span id='error_mess'>"+mess + "</span>");
}
function getIndex(account,tmp){
	var index = (Math.floor ( Math.random ( ) * account.length) );
	if(in_array(index,tmp)){
		index = getIndex(account,tmp);
	}
	return index;
}
//Update 04/08/2009
function getTextAcc(acc){	
	//var html = '<input class="ip-form" name="sUserName" id="sUserName" value="'+acc+'" maxlength="24" type="text" size="20" onkeydown = "keyhandler()" onkeypress ="keyhandler()" onblur="checkAcc();return false;"  />';
    //html+= '<a href="javascript:void(0)" onclick="checkAcc();return false;"   class="form-check">&nbsp;Kiểm tra</a></span>';
	
	return html;
}
function getLabeltAcc(acc){	
	var html = '<input name="sUserName" id="sUserName" value="'+acc+'" type="hidden"><span style="float: left;line-height: 30px;"><b>'+acc+'</b></span>';
    html+= '<a href="javascript:void(0)" style="" class="form-check" onclick="changeText(\''+acc+'\');return false;">Thay đổi</a></span>';
	return html;
}
function changeText(acc){
	var str = getTextAcc(acc);
	$('#label_sUserName').html(str);
	$('#sUserName').focus();
	//fix bug change account
	cur_acc = '';
	account_list = '';
	flag_acc_status = false;
	flag_valid_acc = 0;
	account_list = '';
	cur_acc_5 = '';
	chkAccErr = '';
}
//End
function selectAcc(acc){
	flag_valid_acc = 1;
	closeSuggest();
	/*
	var str = getLabeltAcc(acc);
	$('#label_sUserName').html(str);
	$('#sPassWord1').focus();
	//$('#sUserName').val(acc);
	*/
}
function closeSuggest(){		
	$("#suggest_account").hide();
}	
function suggestion_error(){
	$('#show_checkaccount').html("<img src='"+ IMG_URL  +"/theme/default/images/icon-notvalid.gif' />");
	/*
	$('#suggest_account').show();
	var html = '<span class="close_suggestion"> <a href="javascript:void(0)" onclick="closeSuggest();">[x]</a> </span>';
		html+= "<div class='title_acc_invalid'>";
		html+= "  Tên đăng nhập đã tồn tại.</div>";
	$('#sub_suggest_account').html(html);
	*/
}
function suggestion_error2(){
	$('#show_checkaccount').html("<img src='"+ IMG_URL  +"/theme/default/images/icon-notvalid.gif' />");
	/*
	$('#suggest_account').show();
	var html = '<span class="close_suggestion"> <a href="javascript:void(0)" onclick="closeSuggest();">[x]</a> </span>';
		html+= "<div class='title_acc_invalid'>";
		//html+= "  Tên đăng nhập đã tồn tại. <br/><a href='javascript:void(0)' onClick='checkAcc(1)' style='color:#0066cc'>Gợi ý tên đăng nhập</a></div>";
		html+= "  Tên đăng nhập đã tồn tại. <br/></div>";
	$('#sub_suggest_account').html(html);*/
	show_error_message("Tên đăng nhập đã tồn tại.");
	flag_error = 1;
	$('#sUserName').focus();
}
///////////////////////
function in_array(needle, haystack, strict) {
    var found = false, key, strict = !!strict; 
    for (key in haystack) {
        if ((strict && haystack[key] === needle) || (!strict && haystack[key] == needle)) {
            found = true;
            break;
        }
    } 
    return found;
}
function resetFormTrial(){
	var frm = document.getElementById("frmRegister");
	frm.sUserName.value = "";
	frm.sPassWord1.value = "";
	frm.sConfirm_PassWord1.value = "";
	frm.sVerifyCode.value = "";
	frm.dongy.checked = false;
	$('#err_form').html('&nbsp;');	
	$('#suggest_tmp').hide();
	frm.sUserName.focus();
	
}
/***** ######################### ********/
function checkTextLengthStatic(str,minlen,obj){
	if(str.length!=minlen){		
		return false;
	}
	return true;
}
function checkImageSecurity(obj,minlen,chkAll){	
	if(!checkTextLengthStatic(trim(obj.value),minlen,obj)){
		return false;
	}
	if(!checkImageSecurityChars(obj.value,obj,chkAll)){
		return false;
	}
	return true;
}
function checkImageSecurityChars(str,obj,chkAll){
		if(chkAll)
			var re = /^[a-zA-Z]*$/;
		else
			var re = /^[a-z]*$/;
		str = trim(str);
		var pos = str.search(re);                                                
		if(pos == -1){			
			return false;
		} 
		else{
			return true;
		}
}
function checkPasswordMatch(p,rp){
	if(p==rp)
		return true;
	else
		return false;
		
}
function checkUnicode(stringIn) {
	retval = false 
	for (var i=0;i<=stringIn.length-1;i++) { 
		if  ( (stringIn.charCodeAt (i) >= 32)&&(stringIn.charCodeAt (i) <= 126) ) { 
				   retval = true;
		}else{
			  retval = false;
			  break;
		}
	}
	return retval;
}
function checkPassFieldUnicode(obj, minlen, maxlen){
	if(checkTextLength(obj.value,minlen,maxlen,obj)==false)	{
	
		return false;
	}
	if(checkUnicode(obj.value)==false){
		
		return false;
	}
	return true;
}

function checkSpecialChars(str,obj,chkAll){
		if(chkAll)
			var re = /^[0-9a-zA-Z]*$/;
		else
			var re = /^[0-9a-z]*$/;
		str = trim(str);
		var pos = str.search(re);                                                
		if(pos == -1){
			return false;
		} 
		else{
			return true;
		}
}
function checkTextLength(str,minlen,maxlen,obj){
	if(str.length<minlen || str.length>maxlen){		
		return false;
	}
	return true;
}
function checkNum(c){
	if(c > 47 && c < 58)
		return true;
	return false;
}
function checkStringIsNum(str){
	for(i=0;i<str.length;i++){
		if(!checkNum(str.charCodeAt(i)))
			return false;
	}
	return true;
}
function checkAccount(obj,minlen,maxlen,chkAll){	
	
	if(obj.value == "Zing ID") {
		show_error_message("Tên đăng nhập phải từ 6-24 ký tự");
			return false;
	}
		if(!checkTextLength(obj.value,minlen,maxlen,obj))
		{
		
			show_error_message("Tên đăng nhập phải từ 6-24 ký tự");
			return false;
		}
	
		
	if(!checkSpecialChars(obj.value,obj,chkAll)) {
		
			show_error_message("Tên đăng nhập trong khoảng a-z, 0-9.");
			return false;
		
	}
	
	if(checkStringIsNum(obj.value)){
		show_error_message("Tên đăng nhập phải có ít nhất 1 chữ cái.");
		return false;	
	}
	if(obj.value.charAt(0) == ' ' || obj.value.charAt(obj.value.length-1) == ' '){
		show_error_message("Tên đăng nhập trong khoảng a-z, 0-9.");
		return false;	
	}	
	
	return true;
}
function trim(text){
	var len=text.length;
	var i=0;
	var j=len-1;
	var s="";	
	while(text.charAt(i)==" ")
		i++;	
	while(text.charAt(j)==" ")
		j--;	
	if(i>j) 
		s="";
	else 
		s=text.substring(i,j+1);	
	return s;
}
function refreshImage(type) {
	 var datetime = new Date(); 
	 if(typeof type =='undefined')
	 {
		document.getElementById("sVerifyImg").src = "/imagesec/index."+datetime.getTime()+".html"; 
	 }else{
		document.getElementById("sVerifyImg").src = "/imagesec/index."+datetime.getTime()+"."+type+".html"; 
	 }
}
function open_mess_error(opt_err,content_err){
	var html_err = '';
	$('#TB_overlay').show();
	setOverlay();
	$('#box_p_mess').show();
	if(opt_err == 2)
		html_err = getError_html(content_err);	
	if(opt_err == 1)
		html_err = content_err;	
	$('#label_content_err').html('Vui lòng kiểm tra lại thông tin sau:')
	$('#content_error').html(html_err);
	$('#dongy').focus();
	
}
function close_mess_error(){
	$('#TB_overlay').hide();
	$('#box_p_mess').hide();
}
function setOverlay(){
	var screenW = 640, screenH = 480;
	if (parseInt(navigator.appVersion)>3) {
		screenW = screen.width;
		screenH = screen.height;	
	}
	if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent) || /Chrome[\/\s](\d+\.\d+)/.test(navigator.userAgent)){
		$('#TB_overlay').addClass('fullscreenFF');
	}else{
		$('#TB_overlay').css("width",screenW+'.px');	
		$('#TB_overlay').css("height",screenH+'.px');
	}
}

/*
Last update : 17/03/2009 - 4h00
*/
function get_html_suggestion1(account){//this funtion use to disable suggestion	 
	var html = '<span class="close_suggestion"> <a href="javascript:void(0)" onclick="closeSuggest();">[x]</a> </span>';
	html+= "<div class='title_acc_invalid'>";
	html+= "Tên đăng nhập đã tồn tại.</div>";
	return html;
}
var timeout;
var flag_error = 0;
function keyhandler() {
	timeout && clearTimeout(timeout);
	timeout = setTimeout(function() {
			checkAcc(2);
	}, 400);
}
function keyhandlerPassConfirm() {
	timeout && clearTimeout(timeout);
	timeout = setTimeout(function() {
			checkPasswordConfirm() ;
	}, 400);
}
function keyhandlerPass() {
	timeout && clearTimeout(timeout);
	timeout = setTimeout(function() {
			checkPassword() ;
	}, 400);
}
function keyhandlerSec() {
	timeout && clearTimeout(timeout);
	timeout = setTimeout(function() {
			checkCaptcha();
	}, 400);
}
$(document).ready(function () {
	initInputUsername();
	$('#sConfirm_PassWord1').blur(function(){
	 
	  checkPasswordConfirm();
	});
	$('#sPassWord1').blur(function(){
	 
	  checkPassword();
	});
	$('#sVerifyCode').blur(function(){
	
	  checkCaptcha();
	});
	$('#sUserName').blur(function(){
	
	  checkAcc(2);
	});
	$('#sUserName').focus();
});
function initInputUsername() {
	var input = document.getElementById('sUserName');
	input.onkeydown = keyhandler;
	input.onkeypress = keyhandler;
	
	var inputPassC = document.getElementById('sConfirm_PassWord1');
	inputPassC.onkeydown = keyhandlerPassConfirm;
	inputPassC.onkeypress = keyhandlerPassConfirm;
	
	var inputPass = document.getElementById('sPassWord1');
	inputPass.onkeydown = keyhandlerPass;
	inputPass.onkeypress = keyhandlerPass;
	
	var inputSec = document.getElementById('sVerifyCode');
	inputSec.onkeydown = keyhandlerSec;
	inputSec.onkeypress = keyhandlerSec;
}

function checkPasswordConfirm() {
	//check pass1
	
	var frm = document.getElementById("frmRegister");
	
	if(frm.sConfirm_PassWord1.value != "" && frm.sConfirm_PassWord1.value != "Xác nhận mật khẩu") {
			ichk = checkPasswordMatch(frm.sConfirm_PassWord1.value,frm.sPassWord1.value);
			if(!ichk){
				
				error_mess = 1;				
				show_error_message(PASS1_AND_CONFIRM_PASS1_NO_MATCH );
				if(frm.sConfirm_PassWord1.value.length >= frm.sPassWord1.value.length) {
					log_action += "22,";
					
				}
				frm.sConfirm_PassWord1.focus();
				flag_error = 3;
				return false;
			} else {
				if(flag_error == 3)
					show_error_message("" );
			}
	} 
	return true;
}
function checkCaptcha() {
	// test capcha
	var frm = document.getElementById("frmRegister");
	if(frm.sVerifyCode.value!="" && frm.sVerifyCode.value !="Mã xác nhận") {
		if(!checkImageSecurity(frm.sVerifyCode,6,true)){
					
			error_mess = 1;
			show_error_message(VERIFY_TEXT_IN_IMAGES_INVALID);
			if(frm.sVerifyCode.value !="Mã xác nhận" || frm.sVerifyCode.value.length >= 6) {
				log_action += "3,";
			}
			//mess_eror += getError_html(VERIFY_TEXT_IN_IMAGES_INVALID);	
			flag_error = 4;
			frm.sVerifyCode.focus();
			return false;
		} else {
			if(flag_error == 4)
				show_error_message("");
		
		}
	}
	return true;
}
function checkPassword() {
	var frm = document.getElementById("frmRegister");

	if(frm.sPassWord1.value!="" && frm.sPassWord1.value !="Mật khẩu") {
			ichk = checkPassFieldUnicode(frm.sPassWord1,6,32);
		if(!ichk){
				
			error_mess = 1;
			show_error_message(PASSWORD1_REG_INVALID);
			if(frm.sPassWord1.value.length >= 6) {
				log_action += "2,";
			}
			$('#sConfirm_PassWord1').val('');
			flag_error = 2;
			frm.sPassWord1.focus();
			return false;
		} else {
			if(flag_error == 2) 
				show_error_message("");
			
		}
	} 
	return true;
}