	
	(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s); js.id = id;
		js.src = "https://img.zing.vn/idzing/theme/default/js/register-2.1.2.js#callbackRegister=RegisterSuccess&productid=49&isLogin=1&captcha=0&callbackLogin=loginSuccess";
		fjs.parentNode.insertBefore(js, fjs);
	} (document, 'script', 'zpp-jssdk'));


	function loginSuccess(data){
		window.location.href = "http://idgunny.zing.vn/index/server";
	}
	function RegisterSuccess(){			
		window.location = "http://idgunny.zing.vn/index/newreg";
	}
			
			